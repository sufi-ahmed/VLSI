
-- VHDL Instantiation Created from source file register_8bit_dff.vhd -- 12:01:03 09/20/2026
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT register_8bit_dff
	PORT(
		CLK : IN std_logic;
		RESET : IN std_logic;
		LOAD : IN std_logic;
		D0 : IN std_logic;
		D1 : IN std_logic;
		D2 : IN std_logic;
		D3 : IN std_logic;
		D4 : IN std_logic;
		D5 : IN std_logic;
		D6 : IN std_logic;
		D7 : IN std_logic;          
		Q0 : OUT std_logic;
		Q1 : OUT std_logic;
		Q2 : OUT std_logic;
		Q3 : OUT std_logic;
		Q4 : OUT std_logic;
		Q5 : OUT std_logic;
		Q6 : OUT std_logic;
		Q7 : OUT std_logic
		);
	END COMPONENT;

	Inst_register_8bit_dff: register_8bit_dff PORT MAP(
		CLK => ,
		RESET => ,
		LOAD => ,
		D0 => ,
		D1 => ,
		D2 => ,
		D3 => ,
		D4 => ,
		D5 => ,
		D6 => ,
		D7 => ,
		Q0 => ,
		Q1 => ,
		Q2 => ,
		Q3 => ,
		Q4 => ,
		Q5 => ,
		Q6 => ,
		Q7 => 
	);


