8-bit ALU  (Xilinx ISE 14.7, VHDL)  -  same style as your Register_/computer project
====================================================================================
Open:  File > Open Project > alu_8bit.xise   (Spartan6 xc6slx4, ISim, VHDL - same as your project)

Hierarchy (top = alu_8bit):
  alu_8bit
   |- alu_control   (OP decoder)
   |- not_gate, and_gate, or_gate, xor_gate, xnor_gate   (your NAND-based gates)
   |- mux4          (B-path select and result select)
   '- adder_8bit    (your adder_4bit x2 -> full_adder -> half_adder)

Operations (OP[2:0]):
  000 A+B   001 A-B   010 A AND B   011 A OR B
  100 A XOR B   101 NOT A   110 A+1   111 A-1
Flags: COUT (carry-out; for SUB 1 = no borrow), ZERO, NEG (=Y7), OVF (signed overflow)
COUT and OVF are 0 for logic operations.

Simulate: Simulation view -> select alu_8bit_tb -> Simulate Behavioral Model.
  Console: "PASS: alu_8bit testbench completed, 4111 vectors OK"
  (alu_control_tb checks the decoder alone.)
Hardware: add your own .ucf (pin LOCs depend on the board).
