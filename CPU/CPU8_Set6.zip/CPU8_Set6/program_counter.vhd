----------------------------------------------------------------------------------
-- Module  : program_counter
-- Student : 22201066  (Set 6: LDI, ADD, SUB, JZ, SHL)
-- 4-bit PC. Synchronous active-high RESET (priority). PC+1, or JUMP_ADDR if JZ taken.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity program_counter is
    Port ( CLK       : in  STD_LOGIC;
           RESET     : in  STD_LOGIC;
           JUMP_EN   : in  STD_LOGIC;
           JUMP_ADDR : in  STD_LOGIC_VECTOR (3 downto 0);
           PC_OUT    : out STD_LOGIC_VECTOR (3 downto 0));
end program_counter;

architecture Behavioral of program_counter is
    signal pc_reg : unsigned(3 downto 0) := (others => '0');
begin
    process (CLK)
    begin
        if rising_edge(CLK) then
            if RESET = '1' then
                pc_reg <= (others => '0');
            elsif JUMP_EN = '1' then
                pc_reg <= unsigned(JUMP_ADDR);
            else
                pc_reg <= pc_reg + 1;
            end if;
        end if;
    end process;
    PC_OUT <= std_logic_vector(pc_reg);
end Behavioral;
