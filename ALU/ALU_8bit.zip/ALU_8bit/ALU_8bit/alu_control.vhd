library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Control decoder for the 8-bit ALU
--  OP  | operation | BSEL (B path) | CIN | RSEL (result mux)  | ARITH
--  000 | A + B     | 00  B         | 0   | 00 adder sum       | 1
--  001 | A - B     | 01  NOT B     | 1   | 00 adder sum       | 1
--  010 | A AND B   | 00  B         | 0   | 01 AND             | 0
--  011 | A OR  B   | 00  B         | 0   | 10 OR              | 0
--  100 | A XOR B   | 00  B         | 0   | 11 XOR             | 0
--  101 | NOT A     | 11  all ones  | 0   | 11 XOR (A xor FF)  | 0
--  110 | A + 1     | 10  all zeros | 1   | 00 adder sum       | 1
--  111 | A - 1     | 11  all ones  | 0   | 00 adder sum       | 1
entity alu_control is
    Port ( OP    : in  STD_LOGIC_VECTOR (2 downto 0);
           BSEL  : out STD_LOGIC_VECTOR (1 downto 0);
           CIN   : out STD_LOGIC;
           RSEL  : out STD_LOGIC_VECTOR (1 downto 0);
           ARITH : out STD_LOGIC);
end alu_control;

architecture Behavioral of alu_control is
begin
    process (OP)
    begin
        case OP is
            when "000"  => BSEL <= "00"; CIN <= '0'; RSEL <= "00"; ARITH <= '1';
            when "001"  => BSEL <= "01"; CIN <= '1'; RSEL <= "00"; ARITH <= '1';
            when "010"  => BSEL <= "00"; CIN <= '0'; RSEL <= "01"; ARITH <= '0';
            when "011"  => BSEL <= "00"; CIN <= '0'; RSEL <= "10"; ARITH <= '0';
            when "100"  => BSEL <= "00"; CIN <= '0'; RSEL <= "11"; ARITH <= '0';
            when "101"  => BSEL <= "11"; CIN <= '0'; RSEL <= "11"; ARITH <= '0';
            when "110"  => BSEL <= "10"; CIN <= '1'; RSEL <= "00"; ARITH <= '1';
            when "111"  => BSEL <= "11"; CIN <= '0'; RSEL <= "00"; ARITH <= '1';
            when others => BSEL <= "00"; CIN <= '0'; RSEL <= "00"; ARITH <= '0';
        end case;
    end process;
end Behavioral;
