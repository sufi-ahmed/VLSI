
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity adder8 is
    Port ( a    : in  STD_LOGIC_VECTOR (7 downto 0);
           b    : in  STD_LOGIC_VECTOR (7 downto 0);
           cin  : in  STD_LOGIC;
           sum  : out STD_LOGIC_VECTOR (7 downto 0);
           cout : out STD_LOGIC);
end adder8;



architecture Structural of adder8 is

    -- your existing 1-bit full adder
    component adder1
        Port ( a    : in  STD_LOGIC;
               b    : in  STD_LOGIC;
               cin  : in  STD_LOGIC;
               sum  : out STD_LOGIC;
               cout : out STD_LOGIC);
    end component;
	 
	     -- carry wires: c(0) = input carry, c(8) = final carry out
    signal c : STD_LOGIC_VECTOR (8 downto 0);

begin


    c(0) <= cin;

    gen_adders : for i in 0 to 7 generate
        FA : adder1
            port map (
                a    => a(i),
                b    => b(i),
                cin  => c(i),
                sum  => sum(i),
                cout => c(i+1)
            );
    end generate;
	 
	 cout <= c(8);

end Structural;
	 