
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity register_8bit_dff is
    Port ( CLK   : in  STD_LOGIC;
           RESET : in  STD_LOGIC;
           LOAD  : in  STD_LOGIC;
           D0, D1, D2, D3, D4, D5, D6, D7 : in  STD_LOGIC;
           Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7 : out STD_LOGIC);
end register_8bit_dff;

architecture Structural of register_8bit_dff is

    component register_1bit_dff
        Port ( CLK   : in  STD_LOGIC;
               RESET : in  STD_LOGIC;
               LOAD  : in  STD_LOGIC;
               D     : in  STD_LOGIC;
               Q     : out STD_LOGIC);
    end component;

begin

    REG0: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D0, Q => Q0 );
    REG1: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D1, Q => Q1 );
    REG2: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D2, Q => Q2 );
    REG3: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D3, Q => Q3 );
    REG4: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D4, Q => Q4 );
    REG5: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D5, Q => Q5 );
    REG6: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D6, Q => Q6 );
    REG7: register_1bit_dff port map ( CLK => CLK, RESET => RESET, LOAD => LOAD, D => D7, Q => Q7 );
end Structural;

