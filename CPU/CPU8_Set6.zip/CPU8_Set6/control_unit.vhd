----------------------------------------------------------------------------------
-- Module  : control_unit
-- Decodes opcode[11:8]. Supported: LDI(0001) ADD(0010) SUB(0011) SHL(1000) JZ(1100)
-- Any other opcode (incl. 0000) = NOP.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity control_unit is
    Port ( OPCODE  : in  STD_LOGIC_VECTOR (3 downto 0);
           Z_FLAG  : in  STD_LOGIC;
           ACC_WE  : out STD_LOGIC;
           Z_WE    : out STD_LOGIC;
           JUMP_EN : out STD_LOGIC;
           ALU_OP  : out STD_LOGIC_VECTOR (3 downto 0));
end control_unit;

architecture Behavioral of control_unit is
begin
    process (OPCODE, Z_FLAG)
    begin
        ACC_WE  <= '0';
        Z_WE    <= '0';
        JUMP_EN <= '0';
        ALU_OP  <= "0000";
        case OPCODE is
            when "0001" =>                       -- LDI
                ACC_WE <= '1'; Z_WE <= '1'; ALU_OP <= "0001";
            when "0010" =>                       -- ADD
                ACC_WE <= '1'; Z_WE <= '1'; ALU_OP <= "0010";
            when "0011" =>                       -- SUB
                ACC_WE <= '1'; Z_WE <= '1'; ALU_OP <= "0011";
            when "1000" =>                       -- SHL
                ACC_WE <= '1'; Z_WE <= '1'; ALU_OP <= "1000";
            when "1100" =>                       -- JZ (Z unchanged)
                if Z_FLAG = '1' then
                    JUMP_EN <= '1';
                end if;
            when others =>                       -- NOP
                null;
        end case;
    end process;
end Behavioral;
