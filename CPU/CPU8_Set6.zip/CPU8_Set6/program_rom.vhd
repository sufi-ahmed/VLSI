----------------------------------------------------------------------------------
-- Module  : program_rom   (16 x 12, combinational read, unused = 0x000 NOP)
-- Set 6 program (Appendix B):
--  0: LDI 0x02  1: SUB 0x01  2: JZ 0x07  3: SUB 0x01  4: JZ 0x07
--  5: ADD 0xAA  6: ADD 0xAA  7: LDI 0x21  8: SHL      9: ADD 0x01
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity program_rom is
    Port ( ADDRESS     : in  STD_LOGIC_VECTOR (3 downto 0);
           INSTRUCTION : out STD_LOGIC_VECTOR (11 downto 0));
end program_rom;

architecture Behavioral of program_rom is
    type rom_type is array (0 to 15) of STD_LOGIC_VECTOR (11 downto 0);
    constant ROM : rom_type := (
        0  => x"102",   -- LDI 0x02
        1  => x"301",   -- SUB 0x01
        2  => x"C07",   -- JZ  0x07
        3  => x"301",   -- SUB 0x01
        4  => x"C07",   -- JZ  0x07
        5  => x"2AA",   -- ADD 0xAA
        6  => x"2AA",   -- ADD 0xAA
        7  => x"121",   -- LDI 0x21
        8  => x"800",   -- SHL
        9  => x"201",   -- ADD 0x01
        others => x"000"  -- NOP
    );
begin
    INSTRUCTION <= ROM(to_integer(unsigned(ADDRESS)));
end Behavioral;
