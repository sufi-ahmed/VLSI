library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- 8-bit ALU, built structurally like adder_8bit / register_8bit_dff:
-- NAND-based gates -> mux4 -> adder_8bit -> this ALU.
--
--  OP  Operation     Notes
--  000 A + B
--  001 A - B         COUT = 1 means "no borrow" (A >= B)
--  010 A AND B
--  011 A OR  B
--  100 A XOR B
--  101 NOT A
--  110 A + 1
--  111 A - 1
--
--  Flags: COUT (adder carry-out, 0 for logic ops), ZERO (Y = 0),
--         NEG (Y(7)), OVF (signed overflow, 0 for logic ops)
entity alu_8bit is
    Port ( A    : in  STD_LOGIC_VECTOR (7 downto 0);
           B    : in  STD_LOGIC_VECTOR (7 downto 0);
           OP   : in  STD_LOGIC_VECTOR (2 downto 0);
           Y    : out STD_LOGIC_VECTOR (7 downto 0);
           COUT : out STD_LOGIC;
           ZERO : out STD_LOGIC;
           NEG  : out STD_LOGIC;
           OVF  : out STD_LOGIC);
end alu_8bit;

architecture Structural of alu_8bit is

    component alu_control
        Port ( OP    : in  STD_LOGIC_VECTOR (2 downto 0);
               BSEL  : out STD_LOGIC_VECTOR (1 downto 0);
               CIN   : out STD_LOGIC;
               RSEL  : out STD_LOGIC_VECTOR (1 downto 0);
               ARITH : out STD_LOGIC);
    end component;

    component not_gate
        Port ( A : in  STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component and_gate
        Port ( A : in  STD_LOGIC;
               B : in  STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component or_gate
        Port ( A : in  STD_LOGIC;
               B : in  STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component xor_gate
        Port ( A : in  STD_LOGIC;
               B : in  STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component xnor_gate
        Port ( A : in  STD_LOGIC;
               B : in  STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component mux4
        Port ( D0  : in  STD_LOGIC;
               D1  : in  STD_LOGIC;
               D2  : in  STD_LOGIC;
               D3  : in  STD_LOGIC;
               SEL : in  STD_LOGIC_VECTOR (1 downto 0);
               Y   : out STD_LOGIC);
    end component;

    component adder_8bit
        Port ( A    : in  STD_LOGIC_VECTOR (7 downto 0);
               B    : in  STD_LOGIC_VECTOR (7 downto 0);
               CIN  : in  STD_LOGIC;
               SUM  : out STD_LOGIC_VECTOR (7 downto 0);
               COUT : out STD_LOGIC);
    end component;

    -- control signals
    signal bsel, rsel            : STD_LOGIC_VECTOR (1 downto 0);
    signal cin_i, arith          : STD_LOGIC;

    -- datapath
    signal nb, badj              : STD_LOGIC_VECTOR (7 downto 0);
    signal sum_i                 : STD_LOGIC_VECTOR (7 downto 0);
    signal and_o, or_o, xor_o    : STD_LOGIC_VECTOR (7 downto 0);
    signal y_i                   : STD_LOGIC_VECTOR (7 downto 0);

    -- flags
    signal cout_raw              : STD_LOGIC;
    signal ovf_x1, ovf_x2, ovf_raw : STD_LOGIC;
    signal z1                    : STD_LOGIC_VECTOR (3 downto 0);
    signal z2                    : STD_LOGIC_VECTOR (1 downto 0);
    signal z3, zero_n            : STD_LOGIC;

begin

    -- 1) decode OP
    CTRL: alu_control port map ( OP => OP, BSEL => bsel, CIN => cin_i,
                                 RSEL => rsel, ARITH => arith );

    -- 2) per-bit slice: B conditioning, logic unit, result select
    GEN_BIT: for i in 0 to 7 generate
        -- B path: 00 = B, 01 = NOT B, 10 = '0', 11 = '1'
        NB_I: not_gate port map ( A => B(i), Y => nb(i) );
        BM_I: mux4     port map ( D0 => B(i), D1 => nb(i), D2 => '0', D3 => '1',
                                  SEL => bsel, Y => badj(i) );

        -- logic unit
        AND_I: and_gate port map ( A => A(i), B => badj(i), Y => and_o(i) );
        OR_I:  or_gate  port map ( A => A(i), B => badj(i), Y => or_o(i)  );
        XOR_I: xor_gate port map ( A => A(i), B => badj(i), Y => xor_o(i) );

        -- result select: 00 = sum, 01 = AND, 10 = OR, 11 = XOR
        RM_I: mux4 port map ( D0 => sum_i(i), D1 => and_o(i), D2 => or_o(i),
                              D3 => xor_o(i), SEL => rsel, Y => y_i(i) );
    end generate GEN_BIT;

    -- 3) arithmetic unit (reuses your adder_8bit)
    ADDER: adder_8bit port map ( A => A, B => badj, CIN => cin_i,
                                 SUM => sum_i, COUT => cout_raw );

    Y <= y_i;

    -- 4) flags
    NEG <= y_i(7);

    -- carry only meaningful for arithmetic ops
    CO_G: and_gate port map ( A => cout_raw, B => arith, Y => COUT );

    -- signed overflow: operands have same sign, result sign differs
    OV1: xnor_gate port map ( A => A(7), B => badj(7), Y => ovf_x1 );
    OV2: xor_gate  port map ( A => A(7), B => sum_i(7), Y => ovf_x2 );
    OV3: and_gate  port map ( A => ovf_x1, B => ovf_x2, Y => ovf_raw );
    OV4: and_gate  port map ( A => ovf_raw, B => arith, Y => OVF );

    -- zero detect: NOT( OR of all 8 result bits )
    Z1_0: or_gate port map ( A => y_i(0), B => y_i(1), Y => z1(0) );
    Z1_1: or_gate port map ( A => y_i(2), B => y_i(3), Y => z1(1) );
    Z1_2: or_gate port map ( A => y_i(4), B => y_i(5), Y => z1(2) );
    Z1_3: or_gate port map ( A => y_i(6), B => y_i(7), Y => z1(3) );
    Z2_0: or_gate port map ( A => z1(0), B => z1(1), Y => z2(0) );
    Z2_1: or_gate port map ( A => z1(2), B => z1(3), Y => z2(1) );
    Z3_0: or_gate port map ( A => z2(0), B => z2(1), Y => z3 );
    ZN:   not_gate port map ( A => z3, Y => ZERO );

end Structural;
