----------------------------------------------------------------------------------
-- Module  : cpu8_top   Mini 8-bit Accumulator CPU - Student 22201066 - Set 6
-- Instruction set: LDI, ADD, SUB, JZ, SHL
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity cpu8_top is
    Port ( CLK   : in  STD_LOGIC;
           RESET : in  STD_LOGIC;
           Q     : out STD_LOGIC_VECTOR (7 downto 0);
           Z     : out STD_LOGIC;
           PC    : out STD_LOGIC_VECTOR (3 downto 0));
end cpu8_top;

architecture Structural of cpu8_top is
    component program_counter is
        Port ( CLK : in STD_LOGIC; RESET : in STD_LOGIC; JUMP_EN : in STD_LOGIC;
               JUMP_ADDR : in STD_LOGIC_VECTOR (3 downto 0);
               PC_OUT : out STD_LOGIC_VECTOR (3 downto 0));
    end component;
    component program_rom is
        Port ( ADDRESS : in STD_LOGIC_VECTOR (3 downto 0);
               INSTRUCTION : out STD_LOGIC_VECTOR (11 downto 0));
    end component;
    component control_unit is
        Port ( OPCODE : in STD_LOGIC_VECTOR (3 downto 0); Z_FLAG : in STD_LOGIC;
               ACC_WE : out STD_LOGIC; Z_WE : out STD_LOGIC; JUMP_EN : out STD_LOGIC;
               ALU_OP : out STD_LOGIC_VECTOR (3 downto 0));
    end component;
    component alu is
        Port ( ACC_IN : in STD_LOGIC_VECTOR (7 downto 0);
               IMM_IN : in STD_LOGIC_VECTOR (7 downto 0);
               ALU_OP : in STD_LOGIC_VECTOR (3 downto 0);
               ALU_OUT : out STD_LOGIC_VECTOR (7 downto 0));
    end component;
    component acc_register is
        Port ( CLK : in STD_LOGIC; RESET : in STD_LOGIC; ACC_WE : in STD_LOGIC;
               Z_WE : in STD_LOGIC; ACC_D : in STD_LOGIC_VECTOR (7 downto 0);
               ACC_Q : out STD_LOGIC_VECTOR (7 downto 0); Z_FLAG : out STD_LOGIC);
    end component;

    signal pc_s    : STD_LOGIC_VECTOR (3 downto 0);
    signal instr_s : STD_LOGIC_VECTOR (11 downto 0);
    signal acc_s   : STD_LOGIC_VECTOR (7 downto 0);
    signal alu_s   : STD_LOGIC_VECTOR (7 downto 0);
    signal z_s     : STD_LOGIC;
    signal acc_we_s, z_we_s, jump_s : STD_LOGIC;
    signal alu_op_s : STD_LOGIC_VECTOR (3 downto 0);
begin
    U_PC  : program_counter port map (CLK => CLK, RESET => RESET, JUMP_EN => jump_s,
                                      JUMP_ADDR => instr_s(3 downto 0), PC_OUT => pc_s);
    U_ROM : program_rom     port map (ADDRESS => pc_s, INSTRUCTION => instr_s);
    U_CU  : control_unit    port map (OPCODE => instr_s(11 downto 8), Z_FLAG => z_s,
                                      ACC_WE => acc_we_s, Z_WE => z_we_s,
                                      JUMP_EN => jump_s, ALU_OP => alu_op_s);
    U_ALU : alu             port map (ACC_IN => acc_s, IMM_IN => instr_s(7 downto 0),
                                      ALU_OP => alu_op_s, ALU_OUT => alu_s);
    U_ACC : acc_register    port map (CLK => CLK, RESET => RESET, ACC_WE => acc_we_s,
                                      Z_WE => z_we_s, ACC_D => alu_s,
                                      ACC_Q => acc_s, Z_FLAG => z_s);
    Q  <= acc_s;
    Z  <= z_s;
    PC <= pc_s;
end Structural;
