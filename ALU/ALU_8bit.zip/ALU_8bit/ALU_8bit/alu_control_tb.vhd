library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity alu_control_tb is
end alu_control_tb;

architecture Behavioral of alu_control_tb is

    component alu_control
        Port ( OP    : in  STD_LOGIC_VECTOR (2 downto 0);
               BSEL  : out STD_LOGIC_VECTOR (1 downto 0);
               CIN   : out STD_LOGIC;
               RSEL  : out STD_LOGIC_VECTOR (1 downto 0);
               ARITH : out STD_LOGIC);
    end component;

    signal OP_tb    : STD_LOGIC_VECTOR (2 downto 0);
    signal BSEL_tb  : STD_LOGIC_VECTOR (1 downto 0);
    signal RSEL_tb  : STD_LOGIC_VECTOR (1 downto 0);
    signal CIN_tb, ARITH_tb : STD_LOGIC;

begin

    UUT: alu_control port map ( OP => OP_tb, BSEL => BSEL_tb, CIN => CIN_tb,
                                RSEL => RSEL_tb, ARITH => ARITH_tb );

    stim_proc: process
    begin
        OP_tb <= "000"; wait for 20 ns;
        assert (BSEL_tb = "00" and CIN_tb = '0' and RSEL_tb = "00" and ARITH_tb = '1')
            report "FAIL: control ADD" severity error;

        OP_tb <= "001"; wait for 20 ns;
        assert (BSEL_tb = "01" and CIN_tb = '1' and RSEL_tb = "00" and ARITH_tb = '1')
            report "FAIL: control SUB" severity error;

        OP_tb <= "010"; wait for 20 ns;
        assert (BSEL_tb = "00" and CIN_tb = '0' and RSEL_tb = "01" and ARITH_tb = '0')
            report "FAIL: control AND" severity error;

        OP_tb <= "011"; wait for 20 ns;
        assert (BSEL_tb = "00" and CIN_tb = '0' and RSEL_tb = "10" and ARITH_tb = '0')
            report "FAIL: control OR" severity error;

        OP_tb <= "100"; wait for 20 ns;
        assert (BSEL_tb = "00" and CIN_tb = '0' and RSEL_tb = "11" and ARITH_tb = '0')
            report "FAIL: control XOR" severity error;

        OP_tb <= "101"; wait for 20 ns;
        assert (BSEL_tb = "11" and CIN_tb = '0' and RSEL_tb = "11" and ARITH_tb = '0')
            report "FAIL: control NOT" severity error;

        OP_tb <= "110"; wait for 20 ns;
        assert (BSEL_tb = "10" and CIN_tb = '1' and RSEL_tb = "00" and ARITH_tb = '1')
            report "FAIL: control INC" severity error;

        OP_tb <= "111"; wait for 20 ns;
        assert (BSEL_tb = "11" and CIN_tb = '0' and RSEL_tb = "00" and ARITH_tb = '1')
            report "FAIL: control DEC" severity error;

        report "PASS: alu_control testbench completed" severity note;
        wait;
    end process;

end Behavioral;
