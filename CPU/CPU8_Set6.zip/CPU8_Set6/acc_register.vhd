----------------------------------------------------------------------------------
-- Module  : acc_register  (ACC + Z flag). Set 6 has no STA/LDR so no R register.
-- Synchronous active-high RESET: ACC <= 0x00, Z <= 1.
-- Z = 1 when the value written to ACC is 0x00.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity acc_register is
    Port ( CLK    : in  STD_LOGIC;
           RESET  : in  STD_LOGIC;
           ACC_WE : in  STD_LOGIC;
           Z_WE   : in  STD_LOGIC;
           ACC_D  : in  STD_LOGIC_VECTOR (7 downto 0);
           ACC_Q  : out STD_LOGIC_VECTOR (7 downto 0);
           Z_FLAG : out STD_LOGIC);
end acc_register;

architecture Behavioral of acc_register is
    signal acc_reg : STD_LOGIC_VECTOR (7 downto 0) := (others => '0');
    signal z_reg   : STD_LOGIC := '1';
begin
    process (CLK)
    begin
        if rising_edge(CLK) then
            if RESET = '1' then
                acc_reg <= (others => '0');
                z_reg   <= '1';
            else
                if ACC_WE = '1' then
                    acc_reg <= ACC_D;
                end if;
                if Z_WE = '1' then
                    if ACC_D = "00000000" then
                        z_reg <= '1';
                    else
                        z_reg <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;
    ACC_Q  <= acc_reg;
    Z_FLAG <= z_reg;
end Behavioral;
