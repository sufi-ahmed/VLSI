----------------------------------------------------------------------------------
-- Module  : alu   (combinational)  LDI / ADD / SUB / SHL
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity alu is
    Port ( ACC_IN  : in  STD_LOGIC_VECTOR (7 downto 0);
           IMM_IN  : in  STD_LOGIC_VECTOR (7 downto 0);
           ALU_OP  : in  STD_LOGIC_VECTOR (3 downto 0);
           ALU_OUT : out STD_LOGIC_VECTOR (7 downto 0));
end alu;

architecture Behavioral of alu is
begin
    process (ACC_IN, IMM_IN, ALU_OP)
    begin
        case ALU_OP is
            when "0001" => ALU_OUT <= IMM_IN;                                              -- LDI
            when "0010" => ALU_OUT <= std_logic_vector(unsigned(ACC_IN) + unsigned(IMM_IN)); -- ADD (carry dropped)
            when "0011" => ALU_OUT <= std_logic_vector(unsigned(ACC_IN) - unsigned(IMM_IN)); -- SUB (mod 256)
            when "1000" => ALU_OUT <= ACC_IN(6 downto 0) & '0';                            -- SHL
            when others => ALU_OUT <= ACC_IN;
        end case;
    end process;
end Behavioral;
