

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;



entity adder8_tb is
end adder8_tb;



architecture Behavior of adder8_tb is

    component adder8
        Port ( a    : in  STD_LOGIC_VECTOR (7 downto 0);
               b    : in  STD_LOGIC_VECTOR (7 downto 0);
               cin  : in  STD_LOGIC;
               sum  : out STD_LOGIC_VECTOR (7 downto 0);
               cout : out STD_LOGIC);
    end component;
	 
	 signal a, b : STD_LOGIC_VECTOR (7 downto 0) := (others => '0');
    signal cin  : STD_LOGIC := '0';
    signal sum  : STD_LOGIC_VECTOR (7 downto 0);
    signal cout : STD_LOGIC;

begin

    uut : adder8
        port map (a => a, b => b, cin => cin, sum => sum, cout => cout);

    stim_proc : process
        variable total : integer;
    begin
	 
	  -- a few hand-picked cases
        a <= x"00"; b <= x"00"; cin <= '0'; wait for 20 ns;
        a <= x"01"; b <= x"01"; cin <= '0'; wait for 20 ns;
		  a <= x"0F"; b <= x"01"; cin <= '0'; wait for 20 ns;
        a <= x"FF"; b <= x"01"; cin <= '0'; wait for 20 ns;  -- overflow: sum=00, cout=1
        a <= x"FF"; b <= x"FF"; cin <= '1'; wait for 20 ns;  -- sum=FF, cout=1          
		  a <= x"55"; b <= x"AA"; cin <= '0'; wait for 20 ns;
        a <= x"55"; b <= x"AA"; cin <= '1'; wait for 20 ns;  -- sum=00, cout=1
		  
		  -- loop with automatic checking
        for i in 0 to 15 loop
            a   <= std_logic_vector(to_unsigned(i * 17, 8));
            b   <= std_logic_vector(to_unsigned(255 - i * 9, 8));
            cin <= '0';
				wait for 10 ns;
            total := to_integer(unsigned(a)) + to_integer(unsigned(b));
            assert to_integer(unsigned(sum)) = (total mod 256)
                report "SUM mismatch" severity error;
            assert (cout = '1') = (total >= 256)
                report "COUT mismatch" severity error;
        end loop;
		  
		  report "Simulation finished" severity note;
        wait;
    end process;

end Behavior;
		  
				
				
	 
	 




