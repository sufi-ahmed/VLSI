----------------------------------------------------------------------------------
-- Testbench : cpu8_top_tb  (Set 6, ID 22201066)
-- Clock + RESET for one rising edge, then one cycle per instruction (8 cycles).
-- Values are checked 1 ns after each rising edge against Appendix B.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity cpu8_top_tb is
end cpu8_top_tb;

architecture Behavioral of cpu8_top_tb is
    component cpu8_top is
        Port ( CLK : in STD_LOGIC; RESET : in STD_LOGIC;
               Q : out STD_LOGIC_VECTOR (7 downto 0); Z : out STD_LOGIC;
               PC : out STD_LOGIC_VECTOR (3 downto 0));
    end component;

    signal CLK   : STD_LOGIC := '0';
    signal RESET : STD_LOGIC := '1';
    signal Q     : STD_LOGIC_VECTOR (7 downto 0);
    signal Z     : STD_LOGIC;
    signal PC    : STD_LOGIC_VECTOR (3 downto 0);
    signal done  : boolean := false;
    constant T   : time := 20 ns;

    procedure check (cyc : in integer;
                     sig_pc : in STD_LOGIC_VECTOR (3 downto 0);
                     sig_q  : in STD_LOGIC_VECTOR (7 downto 0);
                     sig_z  : in STD_LOGIC;
                     exp_pc : in STD_LOGIC_VECTOR (3 downto 0);
                     exp_q  : in STD_LOGIC_VECTOR (7 downto 0);
                     exp_z  : in STD_LOGIC) is
    begin
        assert (sig_pc = exp_pc) and (sig_q = exp_q) and (sig_z = exp_z)
            report "MISMATCH at cycle " & integer'image(cyc) severity error;
    end procedure;
begin
    UUT : cpu8_top port map (CLK => CLK, RESET => RESET, Q => Q, Z => Z, PC => PC);

    clk_gen : process
    begin
        while not done loop
            CLK <= '0'; wait for T/2;
            CLK <= '1'; wait for T/2;
        end loop;
        wait;
    end process;

    stim : process
    begin
        -- cycle 0 : RESET = 1 for one rising edge
        RESET <= '1';
        wait until rising_edge(CLK); wait for 1 ns;
        check(0, PC, Q, Z, x"0", x"00", '1');
        RESET <= '0';

        wait until rising_edge(CLK); wait for 1 ns;  -- 1: LDI 0x02
        check(1, PC, Q, Z, x"1", x"02", '0');
        wait until rising_edge(CLK); wait for 1 ns;  -- 2: SUB 0x01
        check(2, PC, Q, Z, x"2", x"01", '0');
        wait until rising_edge(CLK); wait for 1 ns;  -- 3: JZ 0x07 (not taken)
        check(3, PC, Q, Z, x"3", x"01", '0');
        wait until rising_edge(CLK); wait for 1 ns;  -- 4: SUB 0x01
        check(4, PC, Q, Z, x"4", x"00", '1');
        wait until rising_edge(CLK); wait for 1 ns;  -- 5: JZ 0x07 (taken)
        check(5, PC, Q, Z, x"7", x"00", '1');
        wait until rising_edge(CLK); wait for 1 ns;  -- 6: LDI 0x21
        check(6, PC, Q, Z, x"8", x"21", '0');
        wait until rising_edge(CLK); wait for 1 ns;  -- 7: SHL
        check(7, PC, Q, Z, x"9", x"42", '0');
        wait until rising_edge(CLK); wait for 1 ns;  -- 8: ADD 0x01
        check(8, PC, Q, Z, x"A", x"43", '0');

        report "PASS: Set 6 (ID 22201066) - all 8 instructions verified." severity note;
        done <= true;   -- stop the clock right after the last instruction
        wait;
    end process;
end Behavioral;
