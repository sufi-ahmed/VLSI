library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity alu_8bit_tb is
end alu_8bit_tb;

architecture Behavioral of alu_8bit_tb is

    component alu_8bit
        Port ( A    : in  STD_LOGIC_VECTOR (7 downto 0);
               B    : in  STD_LOGIC_VECTOR (7 downto 0);
               OP   : in  STD_LOGIC_VECTOR (2 downto 0);
               Y    : out STD_LOGIC_VECTOR (7 downto 0);
               COUT : out STD_LOGIC;
               ZERO : out STD_LOGIC;
               NEG  : out STD_LOGIC;
               OVF  : out STD_LOGIC);
    end component;

    signal A_tb, B_tb, Y_tb : STD_LOGIC_VECTOR (7 downto 0);
    signal OP_tb            : STD_LOGIC_VECTOR (2 downto 0);
    signal COUT_tb, ZERO_tb, NEG_tb, OVF_tb : STD_LOGIC;

begin

    UUT: alu_8bit port map ( A => A_tb, B => B_tb, OP => OP_tb, Y => Y_tb,
                             COUT => COUT_tb, ZERO => ZERO_tb,
                             NEG => NEG_tb, OVF => OVF_tb );

    stim_proc: process
        variable errors : integer := 0;
        variable tests  : integer := 0;

        -- apply one vector, compute the expected result, compare everything
        procedure check (a : integer; b : integer; op : integer) is
            variable ua, ub : unsigned (7 downto 0);
            variable badj, cin, tot, y, exp_c, exp_o : integer;
            variable a7, b7, y7 : integer;
            variable arith : boolean;
            variable e_y    : STD_LOGIC_VECTOR (7 downto 0);
            variable e_c, e_z, e_n, e_o : STD_LOGIC;
        begin
            A_tb  <= STD_LOGIC_VECTOR(to_unsigned(a, 8));
            B_tb  <= STD_LOGIC_VECTOR(to_unsigned(b, 8));
            OP_tb <= STD_LOGIC_VECTOR(to_unsigned(op, 3));
            wait for 10 ns;

            ua := to_unsigned(a, 8);
            ub := to_unsigned(b, 8);
            badj := 0; cin := 0; y := 0; arith := false;

            case op is
                when 0 => badj := b;       cin := 0; arith := true;   -- ADD
                when 1 => badj := 255 - b; cin := 1; arith := true;   -- SUB
                when 2 => y := to_integer(ua and ub);                 -- AND
                when 3 => y := to_integer(ua or  ub);                 -- OR
                when 4 => y := to_integer(ua xor ub);                 -- XOR
                when 5 => y := to_integer(not ua);                    -- NOT A
                when 6 => badj := 0;       cin := 1; arith := true;   -- INC
                when others => badj := 255; cin := 0; arith := true;  -- DEC
            end case;

            exp_c := 0; exp_o := 0;
            if arith then
                tot   := a + badj + cin;
                y     := tot mod 256;
                exp_c := tot / 256;
                a7 := a / 128;  b7 := badj / 128;  y7 := y / 128;
                if (a7 = b7) and (a7 /= y7) then exp_o := 1; end if;
            end if;

            e_y := STD_LOGIC_VECTOR(to_unsigned(y, 8));
            if exp_c = 1 then e_c := '1'; else e_c := '0'; end if;
            if exp_o = 1 then e_o := '1'; else e_o := '0'; end if;
            if y = 0     then e_z := '1'; else e_z := '0'; end if;
            if y >= 128  then e_n := '1'; else e_n := '0'; end if;

            tests := tests + 1;
            if not (Y_tb = e_y and COUT_tb = e_c and ZERO_tb = e_z and
                    NEG_tb = e_n and OVF_tb = e_o) then
                errors := errors + 1;
                report "FAIL: op=" & integer'image(op) &
                       " A=" & integer'image(a) & " B=" & integer'image(b) &
                       " Y=" & integer'image(to_integer(unsigned(Y_tb))) &
                       " expected " & integer'image(y)
                       severity error;
            end if;
        end procedure;

    begin
        -- directed corner cases
        check(  0,   0, 0);   -- 0 + 0 -> zero flag
        check(255,   1, 0);   -- carry out, result 0
        check(127,   1, 0);   -- signed overflow (127+1)
        check( 15,   1, 0);   -- nibble carry
        check( 50,  20, 1);   -- 50 - 20 = 30
        check( 20,  50, 1);   -- negative result, no-borrow flag = 0
        check(128,   1, 1);   -- signed overflow on SUB
        check(255,   0, 6);   -- INC wraps to 0
        check(127,   0, 6);   -- INC signed overflow
        check(  0,   0, 7);   -- DEC wraps to FF
        check(128,   0, 7);   -- DEC signed overflow
        check(240,  15, 2);   -- AND -> zero
        check(240,  15, 3);   -- OR  -> FF
        check(170,  85, 4);   -- XOR -> FF
        check(170,   0, 5);   -- NOT -> 55

        -- sweep 1: A, B in {00,11,22,...,FF}, all 8 operations
        for op in 0 to 7 loop
            for i in 0 to 15 loop
                for j in 0 to 15 loop
                    check(i * 17, j * 17, op);
                end loop;
            end loop;
        end loop;

        -- sweep 2: odd-looking values, all 8 operations
        for op in 0 to 7 loop
            for i in 0 to 15 loop
                for j in 0 to 15 loop
                    check(i * 16 + 5, j * 13 + 3, op);
                end loop;
            end loop;
        end loop;

        if errors = 0 then
            report "PASS: alu_8bit testbench completed, " &
                   integer'image(tests) & " vectors OK" severity note;
        else
            report "FAIL: alu_8bit testbench, " & integer'image(errors) &
                   " errors out of " & integer'image(tests) severity failure;
        end if;
        wait;
    end process;

end Behavioral;
