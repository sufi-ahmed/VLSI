# Backup method (jodi .xise na khule). ISE Design Suite Command Prompt / terminal e ei folder e giye:
#     xtclsh create_project.tcl
# tarpor File > Open Project > CPU8_Set6_alt.xise
project new CPU8_Set6_alt.xise
project set family Spartan6
project set device xc6slx4
project set package tqg144
project set speed -3
project set "Preferred Language" VHDL
foreach f {program_counter.vhd program_rom.vhd control_unit.vhd alu.vhd acc_register.vhd cpu8_top.vhd cpu8_top_tb.vhd} { xfile add $f }
project set top Structural [file normalize cpu8_top.vhd]
project save
project close
