library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity adder1 is
    Port ( a    : in  STD_LOGIC;
           b    : in  STD_LOGIC;
           cin  : in  STD_LOGIC;
           sum  : out STD_LOGIC;
           cout : out STD_LOGIC);
end adder1;

architecture Dataflow of adder1 is
begin
    sum  <= a xor b xor cin;
    cout <= (a and b) or (b and cin) or (a and cin);
end Dataflow;